using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KhumaloCraft.Pages
{
    public class SendNotificationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
