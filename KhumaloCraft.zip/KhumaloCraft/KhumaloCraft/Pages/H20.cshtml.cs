using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KhumaloCraft.Pages
{
    public class H20Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
