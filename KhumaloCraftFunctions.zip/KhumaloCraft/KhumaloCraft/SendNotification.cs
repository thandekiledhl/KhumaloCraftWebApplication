using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

public static class SendNotification
{
    [FunctionName("SendNotification")]
    public static async Task<bool> Run(
        [ActivityTrigger] string message,
        ILogger log)
    {
        log.LogInformation($"Sending notification: {message}");
        
        await NotificationService.Send(message);

        return true;
    }
}

internal class NotificationService
{
    internal static async Task Send(string message)
    {
        throw new NotImplementedException();
    }
}