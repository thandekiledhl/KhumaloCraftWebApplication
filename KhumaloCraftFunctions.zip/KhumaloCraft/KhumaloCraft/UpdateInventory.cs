using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

public static class UpdateInventory
{
    [FunctionName("UpdateInventory")]
    public static async Task<bool> Run(
        [ActivityTrigger] string orderId,
        ILogger log)
    {
       log.LogInformation($"Updating inventory for order {orderId}.");

        try
        {
            await InventoryService.Update(orderId);
            return true;
        }
        catch (Exception ex)
        {
            log.LogError($"Error updating inventory for order {orderId}: {ex.Message}");
            return false;
        }
    }
}

internal class InventoryService
{
    internal static async Task Update(string orderId)
    {
        throw new NotImplementedException();
    }
}