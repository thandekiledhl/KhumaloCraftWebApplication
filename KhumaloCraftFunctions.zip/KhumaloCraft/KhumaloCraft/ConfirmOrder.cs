using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

public static class ConfirmOrder
{
    [FunctionName("ConfirmOrder")]
    public static async Task<bool> Run(
        [ActivityTrigger] string orderId,
        ILogger log)
    {
        log.LogInformation($"Confirming order {orderId}.");
        await OrderService.Confirm(orderId);

        return true;
    }
}

internal class OrderService
{
    internal static async Task Confirm(string orderId)
    {
        throw new NotImplementedException();
    }
}