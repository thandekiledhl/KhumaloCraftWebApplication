using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;

public static class OrderOrchestrator
{
    [FunctionName("OrderOrchestrator")]
    public static async Task RunOrchestrator(
        [OrchestrationTrigger] IDurableOrchestrationContext context,
        ILogger log)
    {
      
        var orderId = context.GetInput<string>();

        
        var inventoryUpdated = await context.CallActivityAsync<bool>("UpdateInventory", orderId);
        if (!inventoryUpdated)
        {
            log.LogError("Failed to update inventory.");
            return;
        }

        
        var paymentProcessed = await context.CallActivityAsync<bool>("ProcessPayment", orderId);
        if (!paymentProcessed)
        {
            log.LogError("Failed to process payment.");
            return;
        }

        
        var orderConfirmed = await context.CallActivityAsync<bool>("ConfirmOrder", orderId);
        if (!orderConfirmed)
        {
            log.LogError("Failed to confirm order.");
            return;
        }

        
        await context.CallActivityAsync<bool>("SendNotification", "Order placed successfully.");
        await context.CallActivityAsync<bool>("SendNotification", "Payment processed successfully.");
        await context.CallActivityAsync<bool>("SendNotification", "Order confirmed successfully.");
    }
}

public interface IDurableOrchestrationContext
{
    Task<T> CallActivityAsync<T>(string v, object orderId);
    object GetInput<T>();
}