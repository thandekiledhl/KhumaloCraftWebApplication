﻿
internal class OrderRepository
{
    internal static async Task GetOrderById(string orderId)
    {
        throw new NotImplementedException();
    }
}